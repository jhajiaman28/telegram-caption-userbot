#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# One-Tap Telegram Userbot Launcher (Termux & Linux)
# ==============================================================================

set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "======================================================"
echo "🤖 Starting Telegram Userbot (Video Caption Generator)"
echo "======================================================"

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "📦 Python3 not detected. Installing python..."
    pkg update -y && pkg install python -y
fi

# Check .env configuration
if [ ! -f ".env" ]; then
    echo "⚠️  No .env file found. Creating from .env.example..."
    cp .env.example .env
    echo ""
    echo "❗ IMPORTANT: Please edit .env with your credentials:"
    echo "   nano .env"
    echo "   (Fill in TELEGRAM_API_ID, TELEGRAM_API_HASH, and GEMINI_API_KEY)"
    echo ""
    exit 1
fi

# Install dependencies if needed
echo "🔍 Checking dependencies..."
python3 -c "import telethon, requests, dotenv" 2>/dev/null || {
    echo "📦 Installing required Python libraries (telethon, requests, python-dotenv)..."
    pip install -r requirements.txt
}

echo "🚀 Launching Userbot..."
python3 userbot.py
