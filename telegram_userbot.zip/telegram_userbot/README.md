# Telegram Topic Video Caption Userbot (24/7 Cloud & Stateless)

A 100% **Termux-Independent**, always-on Telegram Userbot built with **Telethon** and **Google Gemini 1.5 Multimodal AI**. It monitors Telegram forum topics, downloads full-resolution Shorts/videos (>20 MB) with zero size restrictions, analyzes the audio/visual content, and posts ready-to-publish captions across 4 platforms.

---

## 🚀 Key Advantages

* **100% Termux-Independent:** Runs 24/7 on free cloud services (Koyeb, Render, Railway, VPS, or Docker). Your tablet does not need to stay on.
* **Stateless Cloud Auth (`TELEGRAM_SESSION_STRING`):** Authenticates via a single environment variable string. No local `.session` files needed on the server.
* **No Admin Rights Needed:** Operates under your Telegram account as a regular member.
* **Bypasses 20 MB Bot Limit:** Uses MTProto to download videos up to 2 GB smoothly on gigabit cloud bandwidth.
* **Automatic Rename Trigger:** Triggers automatically as soon as any topic is renamed to include **`[Final]`**. *(Includes manual `.final` command shortcut as well).*
* **4 Tailored Outputs:**
  1. 📱 **WhatsApp Post** (`*bold*`, `_italics_`, hook, core lesson, reflection question)
  2. 💬 **WhatsApp Status** (1–3 punchy, high-impact lines)
  3. 📸 **Instagram** (Scroll-stopping hook, concise caption, CTA, 15–20 hashtags)
  4. ▶️ **YouTube Shorts** (High-CTR Title under 90 chars, SEO description, tags)
  *(Telegram caption completely excluded).*

---

## 🛠️ Step 1: Get Credentials (3 Minutes)

1. **Telegram API ID & Hash:**
   * Log in to [my.telegram.org](https://my.telegram.org).
   * Go to **API development tools** and copy your `api_id` and `api_hash`.
2. **Gemini API Key:**
   * Get a free key at [Google AI Studio](https://aistudio.google.com).
3. **Generate your Session String (One-Time):**
   * Run the session generator once locally or on any machine:
     ```bash
     python3 generate_session.py
     ```
   * Enter your phone number and Telegram login code. It will print a `TELEGRAM_SESSION_STRING`.
   * Copy this string. This string replaces all session files and allows your userbot to run on any cloud platform statelessly!

---

## ☁️ Step 2: Deploy 24/7 in the Cloud (Zero Termux Required)

### Option A: Free Cloud Container (Koyeb or Render) — Recommended
1. Push this folder to a private GitHub repository.
2. In **[Koyeb](https://www.koyeb.com)** or **[Render](https://render.com)**, create a new **Worker Service** linked to your GitHub repo.
3. Add these 4 Environment Variables in the cloud dashboard:
   * `TELEGRAM_API_ID` = `your_api_id`
   * `TELEGRAM_API_HASH` = `your_api_hash`
   * `TELEGRAM_SESSION_STRING` = `your_session_string`
   * `GEMINI_API_KEY` = `your_gemini_api_key`
4. Click **Deploy**. The service will build and run 24/7 in the cloud without using your tablet or battery!

### Option B: Cloud VPS / Server (Docker)
On any Linux / VPS instance:
```bash
docker compose up -d
```
The container runs silently in the background, auto-restarts on server reboot, and processes all videos 24/7.
